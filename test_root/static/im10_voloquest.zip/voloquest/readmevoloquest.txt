This Iron Modder 10 entry adds one encounter with the famous Bard and Travelogue Author Volo to the Temple District. It even provides a chance to discover the meaning of life as we know it. If you wish, you can even read into it the meanings of religion, gaming, and certainly modding...

It has options for every single standard BioWare NPC to discuss Volo and his humor if they are in the party when the quest is explained or resolved.

Most of all, it will take as much or as little game time as your heart desires.

Instructions are simple; install the mod, fill up your party with 5 NPCs (or not), and show up at the Temple District. Talk to the Bard, he is lonely and down in the mouth...

and follow his instructions.

Or not. :)


Try it agin with different NPCs, because they all get a chance to make opening and closing comments.


PERMISSIONS: This modding entry is a free and public gift to the IE community, and may freely be used, messed with, mirrored, adapted, expanded, claimed, turned into your next great novel, retitled and claimed as your own (though if you do it probably would be a good idea to add some more dialogue, and tuck in some more fun stuff, or really there is not much point to doing this), or generally incorporated anywhere, as long as you make no money off of it.Take it, and hopefully it will entertain you for a bit!


If you want the "True Iron Modder Experience" that the judges received, either PM me or revert the following typos and cosmetic changes from the package (no content has been changed, enabled, or disabled.)

Changes from Submitted Version:

tp2, line 89, repaired two instances of \ to / for mac/linux distribution compatibility.
tp2, line 89, repaired filename to Community Prefix designation [placevolo.baf >> c-placevolo.baf]

filename change, voloquest/baf/placevolo.baf >> voloquest/baf/c-placevolo.baf
filename changes; all folders and files to lowercase for linux/moc os compatibility

c-voloquest.d, line 14, to uppercase "I".
c-voloquest.d, lines 8 and 15, added EscapeArea() to remove Volo from the area.
Removed uncalled/unset variables left in entry from scrapped side dialogues and materials left on the cutting room floor, lines 21 - 29
[code]
// == ~C-VOLO~ IF ~Global("C-VoloBG","GLOBAL",1)~ THEN ~In fact, I remember you from our meeting along the Sword Coast, I believe.~
// == ~C-VOLO~ IF ~Global("C-VoloBGGarrick","GLOBAL",1)~ THEN ~I seem to vaguely remember a fair boy, first starting as a bard... Garrick? Yes, that was it, our old friend Garrick.~
// == ~C-VOLO~ IF ~Global("C-VoloBGEldoth","GLOBAL",1)~ THEN ~And there was a bard, sharp of wit and toungue, and smore slippery than an eel accompanying you, a fellow bard. Eldoth. I remember him.~
// == ~C-VOLO~ IF ~Global("C-VoloBGJaheira","GLOBAL",1) InParty("Jaheira") InMyArea("Jaheira") !StateCheck("Jaheira",CD_STATE_NOTVALID)~ THEN ~You, my fine follower of Nature, I remember completely. You have changed, though - your eyes are saddened.~
// == ~JAHEIRAJ~ IF ~Global("C-VoloBGJaheira","GLOBAL",1) InParty("Jaheira") InMyArea("Jaheira") !StateCheck("Jaheira",CD_STATE_NOTVALID)~ THEN ~Speak not of my eyes, bard. I do not wish the memories.~
// == ~C-VOLO~ IF ~Global("C-VoloBGMinsc","GLOBAL",1) InParty("Minsc") InMyArea("Minsc") !StateCheck("Minsc",CD_STATE_NOTVALID)~ THEN ~And who could forget our hamster and his pet Ranger... Misc and Boo, companions forever!~
// == ~IMOEN2J~ IF ~Global("C-VoloBGImoen","GLOBAL",1) InParty("Imoen2") InMyArea("Imoen2") !StateCheck("Imoen2",CD_STATE_NOTVALID)~ THEN ~Heya! Yep, let's help him. We could make it feel like old times, more comfy and all. I miss feeling comfortable. I... I miss saying 'heya'.~
// == ~C-VOLO~ IF ~Global("C-VoloBGImoen","GLOBAL",1) InParty("Imoen2") InMyArea("Imoen2") !StateCheck("Imoen2",CD_STATE_NOTVALID)~ THEN ~I do not recognise you, fair lady... wait. Is that you, Imoen? You have changed greatly, my girl. Life tears at you like dull shears through muslin sheets. I am sorry for your pain, Imoen. You wear your scars on your face as well as on your spirit.~
// == ~C-VOLO~ IF ~Global("C-VoloBG","GLOBAL",1)~ THEN ~But enough of this talk of the past.~
[/code]
and again line 33
[code]
//== ~C-VOLO~ IF ~GlobalGT("C-VoloBG","GLOBAL",1)~ THEN ~For old times sake, perhaps?~
[/code]
Removed vestiges of scrapped after-encounter dialogue, dumped due to time constraints: SetGlobal("C-VoloLeaves","GLOBAL",1) removed from lines 8 and 15
line 32,38, 49, "i" to "I"
line 43, Jan's longwinded story, "i" to "I", "evben" to "even"
line 44, Keldorn, "soething" to "something"
line 51, Viconia, "inded" to "indeed"
line 57, extraneous "later" at end of dialogue removed.
line 70, Volo, "sighs mightly, but rols back to where the baby tomato is dawdfling." to "mightily, "rolls", "dawdling"
line 70, Volo, "dawdling" again.
line 87, Cernd, "attachedto" to "attached to", "perhas" to "perhaps"
line 88, Edwin, Tayvian to "Thayvian"
line 89, Haerdalis, "inded" to "indeed"
line 94, Mazzy, "yu" to "you"
line 109, statename from "StartFirstDiscussion" to "StartDelayedDiscussion"
line 113, PC response, "eplain" to "explain"
line 133, Volo, edited end to "Have you found the Guildmistress to talk to?"
line 141, Volo, "inkeeper" to "Innkeeper"
Line 143, Volo, removed duplicate DO ~SetGlobal("C-IM10VoloQuestProgress","GLOBAL",3)~
lines 146, 159, Volo, capital "H" to start second sentence.
line 167, Volo, "eperiences" to "experiences"
line 194, Keldorn, missing ' at start of quoted aphorism added.
line 204, Edwin, holy typofest, batman: the final form after repair,
== ~EDWINJ~ IF ~InParty("Viconia") InMyArea("Viconia") !StateCheck("Viconia",CD_STATE_NOTVALID) InParty("Edwin") InMyArea("Edwin") !StateCheck("Edwin",CD_STATE_NOTVALID)~ THEN ~So you do find me attractive. (Though the dark elf should have used 'intelligent', or 'deceitful'. And I do not smell of anything, except perhaps power. And persimmon.)~
(Don't even ask. Same exact wording, I just ended up typing them as a wordjumble puzzle. I shudder in shame.)
line 205, Yoshimo, "outr" to "our", "recpmense" to "recompense"
line 208, PC reply,"biding" to "bidding"

And finally, updating and addtiton of text to this ReadMe for the distribution version of this iron modder 10 entry. Thanks to JCompton and PPG for hosting another Iron Modder Competition, and for the opportunity to test out what I can push myself to do in a short frenzied modding session. Thanks and apologies to JCompton, CamDawg, SConrad, and Major Tom Sawyer for judging, and only kindly giggling at my typos; and thank you to my wife for not throwing me out of the house for choosing a modding session over family stuff!
Sincerely, cmorgan. Thursday, December 11, 2007.